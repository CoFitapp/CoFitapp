
import React, { useState, useEffect, useRef } from 'react';

import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

import { SafeAreaView, ImageBackground, FlatList, Dimensions, NativeModules, Image, PermissionsAndroid, StyleSheet, Text, View } from 'react-native';
import { GooglePlacesAutocomplete } from 'react-native-google-places-autocomplete';

import MapView, { Marker,AnimatedRegion,Animated } from 'react-native-maps';
import Geolocation from 'react-native-geolocation-service';
const { height, width } = Dimensions.get('window')
const { StatusBarManager } = NativeModules;
const statusBarHeight = StatusBarManager.HEIGHT;
import Geocoder from 'react-native-geocoding';

import BottomSheet from "react-native-gesture-bottom-sheet";
import styles from './style';
import { useIsFocused } from '@react-navigation/native';
import images from '../../constants/images';
import { useSelector } from 'react-redux';
import { Auth } from 'aws-amplify';
import axios from 'axios';
import getDistance from '../../api/getDistance';

Geocoder.init("AIzaSyBpVX6Xl4OEftECYrN-wauMw7dpUyl6GiI");
const apiKey = "AIzaSyBpVX6Xl4OEftECYrN-wauMw7dpUyl6GiI";
const httpLinkPattern = /^(http|https):\/\/[^\s/$.?#].[^\s]*$/i;

const Map = ({navigation}) => {
  const userLocation = useSelector(state=>state.user.location)
  const [auto, setAuto] = useState(true)
  const bottomSheet = useRef();
  const isFocused = useIsFocused();
  const [latitude, setLatitude] = useState(0);
  const [longitude, setLongitude] = useState(0);
  const [mapVisible, setMapVisible] = useState(false)
  const [loader, setLoader] = useState(true)
  const [address, setAddress] = useState('')
  const [eventCoords,setEventCoords]=useState([])
  const [events, setEvents] = useState([
    {
      'image': images.event1,
      'distance': "8+",
      'time': "Tue, Sep 12 | 7:00pm",
      'name': "Fitness Challenge - Get Trophy by Courier",
      'location': "4550 Mueller bivid park, NJ"
    },
    {
      'image': images.event2,
      'distance': "12+",
      'time': "Tue, Sep 12 | 7:00pm",
      'name': "Fitness Challenge - Get Trophy by Courier",
      'location': "4550 Mueller bivid park, NJ"
    },
    {
      'image': images.event1,
      'distance': "8+",
      'time': "Tue, Sep 12 | 7:00pm",
      'name': "Fitness Challenge - Get Trophy by Courier",
      'location': "4550 Mueller bivid park, NJ"
    },
    {
      'image': images.event2,
      'distance': "12+",
      'time': "Tue, Sep 12 | 7:00pm",
      'name': "Fitness Challenge - Get Trophy by Courier",
      'location': "4550 Mueller bivid park, NJ"
    },
  ])

  useEffect(() => {
    if (isFocused) {
      getCoordinatesForLocation(userLocation);
      getEventCoords();
      // requestLocationPermission();
    }
  }, [isFocused])


  const getCoordinatesForLocation = async (locationn) => {
    console.log('userLocation',userLocation);
    
    try {
      const response = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(locationn)}&key=${apiKey}`);
      const data = await response.json();
  
      if (data.results.length > 0) {
        const locationData = data.results[0].geometry.location;
        console.log('duy23y723y8y328',locationData);
        setLatitude(locationData.lat);
            setLongitude(locationData.lng);
            setMapVisible(true)
      } else {
        console.error(`No results found for the provided location: ${userLocation}`);
        
      }
    } catch (error) {
      console.error(`Error fetching geocode data for location: ${userLocation}`, error);
    }
  };
  
  const getEventCoords = async () => {
    try {
      let info = await Auth.currentSession();
      let token = info.idToken.payload.profile
      let config = {
        method: 'get',
        url: 'https://www.googleapis.com/calendar/v3/calendars/primary/events',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      };
  
      const response = await axios.request(config);
      const arr = []
     response.data.items.map((item) =>{
      
      if(item?.location){
        const ishttpLink = httpLinkPattern.test(item.location)
        if(!ishttpLink){
          arr.push(item)
        }
      }
     
     });
  console.log('arrrrrrr',arr);

  // Fetch coordinates for each location
      const coordinatesPromises = arr.map((itemm) => fetchCoordinatesForLocation(itemm));
      const coordinates = await Promise.all(coordinatesPromises);
  
      // coordinates array now contains the latitude and longitude for each location
      console.log("sdfsdsfdsdsdadfsdsddgdfg", coordinates);
       setEventCoords(coordinates)
    } catch (error) {
      console.error(error);
    }
  };

   const fetchCoordinatesForLocation = async (item) => {
    try {
      const response = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(item.location)}&key=${apiKey}`);
      const data = await response.json();
  
      if (data.results.length > 0) {
        const locationData = data.results[0].geometry.location;
        return {...item, latitude: locationData.lat, longitude: locationData.lng };
      } else {
        console.error(`No results found for the provided location: ${location}`);
        return null;
      }
    } catch (error) {
      console.error(`Error fetching geocode data for location: ${location}`, error);
      return null;
    }
  };
  

  async function requestLocationPermission() {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: 'Location Permission',
          message: 'This app needs access to your location to provide location-based services.',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        }
      );

      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        console.log('Location permission granted.');
        Geolocation.getCurrentPosition(
          (position) => {
            setLatitude(position.coords.latitude);
            setLongitude(position.coords.longitude);
            console.log("dsads", latitude)
            console.log("sdfsd", longitude)
            Geocoder.from(position.coords.latitude, position.coords.longitude)
              .then((json) => {
                console.log("asnbmbmbnmbmbnkljmbmnbmdasd", json.results[0].address_components)
                const addressComponent = json.plus_code.compound_code;
                console.log("sdfsfs", addressComponent)
                setAddress(addressComponent)
                setMapVisible(true)
                setLoader(false);
              })
              .catch((error) => {
                console.warn('Geocoder error:', error);
                setLoader(false);
              })
          })
      } else {
        console.log('Location permission denied.');
      }
    } catch (err) {
      console.warn(err);
    }
  }

  const fetchLocationOnDragMarker = (coords) => {
    // console.log('123232sdsasadsadsadssda32321321',e.nativeEvent.coordinate);
    //  alert(JSON.stringify(e.nativeEvent.coordinate))
    setLatitude(coords.latitude)
    setLongitude(coords.longitude)
    Geocoder.from(coords.latitude, coords.longitude)
      .then(json => {
        var addressComponent = json.results[0].formatted_address;
        console.log("address>>>>>>", addressComponent);
        console.log("address>>>>>>", json.results);
        // setAddress(addressComponent)
      })
      .catch(error => console.warn(error));
  }

  const onPressMarker=async(item)=>{
    let dis = await getDistance(userLocation,item.location)
    // console.log('8376432864786237aaaa',dis);
    // return;
    navigation.navigate("EventDetail",{item:{...item,distance:dis}})
  }
  return (

    <SafeAreaView style={{ flex: 1 }}>
      {/* <Text style=
      {{position:"absolute",top:0,bottom:0,left:0,right:0,color:'black'}}>{address}</Text> */}
      {mapVisible &&
        <View style={styles.container}>
          <MapView
          zoomEnabled={true}
          minZoomLevel={1}
            style={styles.mapStyle}
            region={{
              latitude: latitude,
              longitude: longitude,
              latitudeDelta: 0.0922,
              longitudeDelta: 0.0421,
            }}
            // onRegionChangeComplete={(val) => fetchLocationOnDragMarker(val)}

          // customMapStyle={mapStyle}
          >
            {/* <Marker
            coordinate={{
              latitude:latitude,
              longitude:longitude,
            }}
            // title={'Test Marker'}
            // description={'This is a description of the marker'}
          /> */}
          {
                        eventCoords.map((item, index) => (
                        
                          <Marker
                            key={index}
                            image={images.location3}
                            title={item.summary}
                            // onPress={()=>alert(1)}
                            onCalloutPress={()=>onPressMarker(item)}
                            // style={{height:50,width:50,}}
                            coordinate={{ latitude: Number(item.latitude), longitude: Number(item.longitude) }}
                          >
                          </Marker>

                        ))
                      }
          </MapView>
          {/* <View pointerEvents="none" style={styles.locIconView}>
            <Image style={styles.location1} source={images.location3} />
          </View> */}
        </View>

      }
      <View style=
        {{
          height: auto == true ? 50 : '100%', width: '90%',
          borderRadius: 10, alignSelf: 'center', alignItems: "center",
          marginHorizontal: "10%", backgroundColor: 'transparent', justifyContent: "center",
          position: "absolute", top: Platform.OS == "ios" ? statusBarHeight + 20 : 25
        }}>

        <GooglePlacesAutocomplete
          placeholder='Search events by location'
          fetchDetails={true}
          keepResultsAfterBlur={true}
          styles={styles.autoComplete}
          renderLeftButton={() => (
            <Image source={images.search} style={styles.location1} />
          )}
          renderRightButton={() => (
            <Image source={images.user} style={styles.user} />
          )} textInputProps={{
            onFocus: () => {
              setAuto(false);
            },

            errorStyle: { color: 'red' }
          }}
          onPress={(data, details = null) => {
            setAuto(true)
            getCoordinatesForLocation(data.description)
            // bottomSheet.current.show()
          }}
          query={{
            key: "AIzaSyBpVX6Xl4OEftECYrN-wauMw7dpUyl6GiI",
            language: 'en',
          }}
        />



      </View>
      <BottomSheet hasDraggableIcon ref={bottomSheet} height={150}  >

        <View style={styles.view}>
          <KeyboardAwareScrollView>
            <View>

              <FlatList
                data={events}
                horizontal={true}

                renderItem={({ item, index }) => {
                  return (

                    <View style={{}}>
                      <ImageBackground resizeMode='contain' source={item.image} style={styles.BgImg}>
                        <View style={styles.kmBtn}>
                          <Image source={images.car} style={styles.carIcon} />
                          <Text style={styles.kmText}>{item.distance} km</Text>
                        </View>
                      </ImageBackground>
                    </View>
                  )
                }}
              />
            </View>
          </KeyboardAwareScrollView>
        </View>
      </BottomSheet>
    </SafeAreaView>
  );
};
export default Map;


