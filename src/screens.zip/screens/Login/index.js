import { NativeModules, StyleSheet, Text, View, useWindowDimensions, Image, Touchable, TouchableOpacity } from 'react-native'
import React, { useEffect, useState } from 'react'
import styles from './style'
import images from '../../constants/images'
import colors from '../../constants/colors'
import { CognitoHostedUIIdentityProvider } from '@aws-amplify/auth';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { login } from '../../redux/slices/userSlice'
import {
  GoogleSignin,
  GoogleSigninButton,
  statusCodes,
} from '@react-native-google-signin/google-signin';
import Toast from 'react-native-simple-toast';
import AsyncStorage from '@react-native-async-storage/async-storage'
import { Amplify, Auth, Hub, Cache } from "aws-amplify";
import { useDispatch } from 'react-redux'

const { StatusBarManager } = NativeModules;
const statusBarHeight = StatusBarManager.HEIGHT;

GoogleSignin.configure({
  scopes: ['https://www.googleapis.com/auth/drive.readonly', 'https://www.googleapis.com/auth/calendar.events.readonly'], // what API you want to access on behalf of the user, default is email and profile

  androidClientId: '1065079397050-c0q82knpg0ckeacgkgvlvn4jck731i2f.apps.googleusercontent.com',
  webClientId: '1065079397050-qcatpbr4j8014mv8khmv7nspt3j6m25f.apps.googleusercontent.com',
  offlineAccess: true, // if you want to access Google API on behalf of the user FROM YOUR SERVER
  forceCodeForRefreshToken: true, // [Android] related to `serverAuthCode`, read the docs link below *.
  iosClientId: '1065079397050-7q3rbeb6gjh5mj0sbgabk65i4747v0o1.apps.googleusercontent.com', // [iOS] optional, if you want to specify the client ID of type iOS (otherwise, it is taken from GoogleService-Info.plist)
});

const LoginScreen = ({ navigation }) => {
  const { height, width } = useWindowDimensions();
  const [user, setUser] = useState({})
  const dispatch = useDispatch();


  // useEffect(() => {
  //   GoogleSignin.configure({
  //     scopes: ['https://www.googleapis.com/auth/drive.readonly', 'https://www.googleapis.com/auth/calendar.events.readonly'], // what API you want to access on behalf of the user, default is email and profile

  //     androidClientId: '1065079397050-c0q82knpg0ckeacgkgvlvn4jck731i2f.apps.googleusercontent.com',
  //     webClientId: '1065079397050-qcatpbr4j8014mv8khmv7nspt3j6m25f.apps.googleusercontent.com',
  //     offlineAccess: true, // if you want to access Google API on behalf of the user FROM YOUR SERVER
  //     forceCodeForRefreshToken: true, // [Android] related to `serverAuthCode`, read the docs link below *.
  //     iosClientId: '1065079397050-7q3rbeb6gjh5mj0sbgabk65i4747v0o1.apps.googleusercontent.com', // [iOS] optional, if you want to specify the client ID of type iOS (otherwise, it is taken from GoogleService-Info.plist)
  //   });

  // }, [])

  useEffect(() => {
    const unsubscribe = Hub.listen("auth", ({ payload: { event, data } }) => {
      console.log('dsnu8g23d238gdsafddsfds32d23d23', JSON.stringify(data));
      // console.log('dsnu8g23dxszs238gdsafdfds32d23d23', data.signInUserSession.idToken.payload.profile);
      console.log('event', event);
      switch (event) {
        case "signIn":
          //  console.log('dsnu8g23d238g32d23d23', data);
          break;
        case "cognitoHostedUI":
          dispatch(login(true))
          // navigation.navigate("SignedInStack")
          navigation.navigate("SelectLocation")
          break;
        case "signOut":
          break;
        case "customOAuthState":
      }
    });

    return unsubscribe;
  }, []);

  const googleLogin = async () => {
    await Auth.federatedSignIn({ provider: CognitoHostedUIIdentityProvider.Google })
  }

  return (
    <View style={styles.mainView}>
      <KeyboardAwareScrollView>
        <View style={{ marginTop: statusBarHeight, flex: 1, }}>
          {/* <View style={styles.skipView}>
            <TouchableOpacity onPress={() => navigation.navigate("SelectLocation")} style={styles.skipbtn}>
              <Text style={{ fontSize: 14, color: "#363C49" }}>Skip</Text>
              <Image style={styles.skipimg} source={images.skip}></Image>
            </TouchableOpacity>
          </View> */}
          <View style={styles.logoView}>
            <Image source={images.cofitLogo} style={styles.cofitImage} />
          </View>
          <View style={styles.backView}>

          </View>
          <View style={styles.startedView}>
            <Text style={styles.startedText}>Let's get started</Text>
            <View style={styles.signUpView}>
              <Text style={styles.signUpText}>
                Signup or login to see what's happening near you.
              </Text>
            </View>
            <View style={styles.logoView1}>
              <Image style={styles.logoimage1} source={images.logo}>

              </Image>
            </View>
          </View>
        </View>
        <View style={styles.bottomView} >
          <TouchableOpacity onPress={() => googleLogin()} style={styles.loginBtn}>
            <Image source={images.google} style={styles.googleIcon1}></Image>
            <Text style={styles.googleText}>Continue with Google</Text>
          </TouchableOpacity>
        </View>

      </KeyboardAwareScrollView>
    </View>
  )
}

export default LoginScreen
