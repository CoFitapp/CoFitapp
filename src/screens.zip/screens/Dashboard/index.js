import { NativeModules, PixelRatio, Image, StyleSheet, Text, View, useWindowDimensions, TextInput, ScrollView, FlatList, ImageBackground, TouchableOpacity, Platform } from 'react-native'
import React, { useEffect, useState } from 'react'
import { useIsFocused, useNavigation } from '@react-navigation/native';
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view"
import images from '../../constants/images';
import fonts from '../../constants/fonts';
import styles from './style';
import {
  GoogleSignin,
  GoogleSigninButton,
  statusCodes,
} from '@react-native-google-signin/google-signin';
import axios from 'axios';
import moment from 'moment';
import { Auth } from 'aws-amplify';
import {useSelector} from 'react-redux'
import DeviceInfo from 'react-native-device-info';
import getDistance from '../../api/getDistance'
import { ActivityIndicator } from 'react-native';

const { StatusBarManager } = NativeModules;
const statusBarHeight = StatusBarManager.HEIGHT;
const fontScale = PixelRatio.getFontScale();
const fontSize = size => size / fontScale;



const Dashboard = () => {
  const isFocused = useIsFocused();
  const navigation = useNavigation();
  const userLocation = useSelector(state=>state.user.location)
  console.log('dyewgdygewgqwdq',userLocation);
  const { height, width } = useWindowDimensions();
  const [searchText,setSearchText]=useState('')
  const [newEvents, setNewEvents] = useState([])
  const [newEvents1, setNewEvents1] = useState([])
  const [selectedIndex, setSelectedIndex] = useState(0)
  const [loader,setLoader]=useState(true)
  // const [token,setToken]=useState('')
  useEffect(() => {
    if(isFocused){
      getEvents();
    }
    
  }, [isFocused])

  // useEffect(()=>{
  //   getUserDetails();
  // },[])

  // const getUserDetails=async()=>{
  //  let info = await Auth.currentAuthenticatedUser();
  //  setToken(info.signInUserSession.idToken.payload.profile)
  // }

  const getEvents = async () => {
   
    let info = await Auth.currentSession();
    console.log('dsjagsasdasjhgdjgja',JSON.stringify(info));
    let token = info.idToken.payload.profile;
    console.log('tkokrusiruiseryyiyiw',token);
    let config = {
      method: 'get',
      url: 'https://www.googleapis.com/calendar/v3/calendars/primary/events',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    };

    axios.request(config)
      .then(async(response) => {
        console.log("evdsdedsnts ddasassdata+++++++++++", response.data.items);
       let promises =  response.data.items.map(async(item,index)=>{
          let dis = await getDistance(userLocation,item.location)
          item.distance = dis
        })
        await Promise.all(promises).then(()=>{
          setTimeout(() => {
        setNewEvents(response.data.items)
        setNewEvents1(response.data.items)
        setLoader(false)
          }, 500);
        })
        
      })
      .catch((error) => {
        console.log(error);
      });

  }


  const onAddFilter = (value) => {
    setSelectedIndex(value)
    setSearchText('')
    if (value == 0) {
      setNewEvents(newEvents1)
    }
    else if (value == 1) {
      let today = moment().format("MM-DD-YYYY")
      let arr = [];
      newEvents1.map((item, index) => {
        let eventdate = moment(item.start.dateTime).format("MM-DD-YYYY")
        if (eventdate == today) {
          arr.push(item)
        }
      })
      setNewEvents(arr)
    }
    else if (value == 2) {
      const currentDate = moment();
      const date1 = currentDate.endOf('week');
      const formattedDate1 = moment(date1).format("MM-DD-YYYY")
      const date2 = currentDate.endOf('week').add(1, 'day');
      const formattedDate2 = moment(date2).format("MM-DD-YYYY")

      let arr = [];
      newEvents1.map((item, index) => {
        let eventdate = moment(item.start.dateTime).format("MM-DD-YYYY")
        if (eventdate == formattedDate1 || eventdate == formattedDate2) {
          arr.push(item)
        }
      })
      setNewEvents(arr)
    }
    else if (value == 3) {
      let week = moment();
      let arr = [];
      newEvents1.map((item, index) => {
        let eventDate = moment(item.start.dateTime);
        let isSameWeek = (week.isoWeek() == eventDate.isoWeek())
        if (isSameWeek) {
          arr.push(item)
        }
      })
      setNewEvents(arr)

    }
    else if (value == 4) {
      let currentMonth = moment().format("MM-YYYY")
      let arr = [];
      newEvents1.map((item, index) => {
        let eventMonth = moment(item.start.dateTime).format("MM-YYYY")
        if (eventMonth == currentMonth) {
          arr.push(item)
        }
      })
      setNewEvents(arr)
    }
  }

  const onSearchEvent=(value)=>{
    setSearchText(value)
    if (value == '' || value.length == 0) {
      setNewEvents(newEvents1)
    } else {
      const newData = newEvents1.filter(item => {
        try {
          const itemData = item.summary.toUpperCase();
          const textData = value.toUpperCase();
          return itemData.indexOf(textData) > -1

        }
        catch (error) {
        }

      })
      setNewEvents(newData)
    }
  }

  return (
    <View style={styles.mainView}>
      <KeyboardAwareScrollView >
        <View style={styles.view1}>
          <View style={{ flexDirection: "column" }}>
            <Text style={styles.findText}>Find events in</Text>
            <View style={styles.newJersyView}>
              <View style={{width:'80%',flexDirection:'row'}}>
              <Text style={styles.newJersyText}>{userLocation}</Text>
              <Image source={images.location} style={styles.locicon} />
              </View>
             <View style={{width:'20%',alignItems:'flex-end'}}>
             <Image source={images.profile_image} style={styles.profileImg} />

             </View>

            </View>
          </View>
        </View>
        <View style={styles.searchView}>
          <View style={styles.searchView1}>
            <Image source={images.search} style={styles.searchIcon} />
            <TextInput
              placeholder='Search upcoming events'
              placeholderTextColor={"#B2BAC7"}
              value={searchText}
              keyboardType='web-search'
              onChangeText={(val)=>onSearchEvent(val)}
              style={styles.searchTextInput}
            />
          </View>
          {/* <View style={styles.filterView}>
            <Image source={images.filter} style={styles.filterIcon} />
          </View> */}

        </View>
        <View style={styles.view2}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.scroll}>
            <TouchableOpacity activeOpacity={0.9} onPress={() => onAddFilter(0)} style={{ justifyContent: "center", alignItems: "center", backgroundColor: selectedIndex == 0 ? "#25C3F4" : "#fff", borderRadius: 5, height: 38, marginLeft: 5, borderWidth: 1, borderColor: "#DCE1E9" }}>
              <Text style={{ fontFamily: fonts.SfPro_Bold, paddingHorizontal: 12, color: selectedIndex == 0 ? "#fff" : "#8B93A1" }}>All</Text>
            </TouchableOpacity>
            <TouchableOpacity activeOpacity={0.9} onPress={() => onAddFilter(1)} style={{ justifyContent: "center", alignItems: "center", backgroundColor: selectedIndex == 1 ? "#25C3F4" : "#fff", borderRadius: 5, height: 38, marginLeft: 5, borderWidth: 1, borderColor: "#DCE1E9" }}>
              <Text style={{ fontFamily: fonts.SfPro_Bold, paddingHorizontal: 12, color: selectedIndex == 1 ? "#fff" : "#8B93A1" }}>Today</Text>
            </TouchableOpacity>
            <TouchableOpacity activeOpacity={0.9} onPress={() => onAddFilter(2)} style={{ justifyContent: "center", alignItems: "center", backgroundColor: selectedIndex == 2 ? "#25C3F4" : "#fff", height: 38, borderRadius: 5, marginLeft: 5, borderWidth: 1, borderColor: "#DCE1E9" }}>
              <Text style={{ fontFamily: fonts.SfPro_Bold, paddingHorizontal: 12, color: selectedIndex == 2 ? "#fff" : "#8B93A1" }}>This weekend</Text>
            </TouchableOpacity>
            <TouchableOpacity activeOpacity={0.9} onPress={() => onAddFilter(3)} style={{ justifyContent: "center", alignItems: "center", backgroundColor: selectedIndex == 3 ? "#25C3F4" : "#fff", height: 38, borderRadius: 5, marginLeft: 5, borderWidth: 1, borderColor: "#DCE1E9" }}>
              <Text style={{ fontFamily: fonts.SfPro_Bold, paddingHorizontal: 12, color: selectedIndex == 3 ? "#fff" : "#8B93A1" }}>This week</Text>
            </TouchableOpacity>
            <TouchableOpacity activeOpacity={0.9} onPress={() => onAddFilter(4)} style={{ justifyContent: "center", alignItems: "center", backgroundColor: selectedIndex == 4 ? "#25C3F4" : "#fff", height: 38, borderRadius: 5, marginLeft: 5, borderWidth: 1, borderColor: "#DCE1E9" }}>
              <Text style={{ fontFamily: fonts.SfPro_Bold, paddingHorizontal: 12, color: selectedIndex == 4 ? "#fff" : "#8B93A1" }}>This Month</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>

        <Text style={styles.eventsText}>Events</Text>
        {
          loader &&
          <ActivityIndicator color={'#000'} size={'large'} style={{marginTop:50}}/>
        }

        {
          (!loader && newEvents.length==0) &&
          <Text style={{fontSize:16,textAlign:"center",fontFamily:fonts.SfPro_Medium,marginTop:50}}>no event found</Text>
        }

        {
          (!loader && newEvents.length!=0) &&
          <FlatList
          data={newEvents}
          scrollEnabled={false}
          renderItem={({ item, index }) => {
            return (
              <TouchableOpacity onPress={()=>navigation.navigate("EventDetail",{item:item})} activeOpacity={0.8} style={styles.flatListView}>
                <View style={styles.flatListView1}>
                  <View style={styles.flatListItem} >
                    <ImageBackground style={styles.flatListImg} resizeMode="stretch" source={images.event1}>
                      <View style={styles.kmbutton}>
                        <Image source={images.car} style={styles.carImg} />
                        <Text style={styles.kmText}>{item.distance}</Text>
                      </View>
                    </ImageBackground>
                  </View>
                <View style={styles.dateView}>
                  <Image source={images.time} style={styles.clockIcon} />
                  <Text style={styles.dateText}>{moment(item.start.dateTime).format('ddd, MMM DD | h:mma')}</Text>
                </View>
                <Text style={styles.summaryText}>{item.summary}</Text>
                <View style={styles.dateView}>
                  <Image source={images.location} style={styles.locIconB} />
                  <Text style={styles.locText}>{item.location}</Text>
                </View>
                <View style={styles.view3} />
                <TouchableOpacity onPress={()=>navigation.navigate("EventDetail")} style={styles.shareBtn}>
                  <Image source={images.share} style={styles.clockIcon} />
                  <Text style={styles.shareText}>Share event</Text>
                </TouchableOpacity>
              </View>
              </TouchableOpacity>
            )
          }}
        />
        }
        
      </KeyboardAwareScrollView>
    </View>

  )
}
export default Dashboard

