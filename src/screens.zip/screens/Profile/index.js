import { NativeModules, StyleSheet, Text, View, useWindowDimensions,Image, Touchable, TouchableOpacity, TextInput, ImageBackground, Platform, Alert } from 'react-native'
import React from 'react'
import styles from './style'
import images from '../../constants/images'
import colors from '../../constants/colors'
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { useDispatch } from 'react-redux'
import { logout } from '../../redux/slices/userSlice'
import { useFocusEffect } from '@react-navigation/native'
import { Auth } from 'aws-amplify'
import { useState } from 'react'


const { StatusBarManager } = NativeModules;
const statusBarHeight = StatusBarManager.HEIGHT;


const Profile = ({navigation}) => {
  const {height,width} = useWindowDimensions();
  const [email,setEmail]=useState('')
  const [name,setName]=useState('')
  const dispatch = useDispatch()

  useFocusEffect(()=>{
    getUserDetails();
  },[])

  const getUserDetails=async()=>{
   let info = await Auth.currentSession();
  //  console.log('76823686dsas23dssew8rt7t32tr',info.signInUserSession.idToken);
  // const updateUser = await Auth.updateUserAttributes(info,{
  //   location:"abc"
  // })
  //  console.log('saghsajdsddjagdyuuguda',updateUser);
  //  return;
   setEmail(info.idToken.payload.email)
   setName(info.idToken.payload.name)
   console.log('userInfo++++++',info.idToken.payload);
  }

  const onLogout=async()=>{
    Alert.alert("Log Out",
    "Are you sure you want to logout",[
      {'text':"Cancel",style:"cancel",onPress:()=>console.log('cancel pressed')},
      {'text':'Ok',onPress:()=>onConfirmLogout()}
    ])
}

const onConfirmLogout=async()=>{
    dispatch(logout())
    navigation.navigate("LoginScreen")
}



  return (
    <View style={styles.mainView}>
        <KeyboardAwareScrollView>
      <View style={{backgroundColor:'#fff',flex:1,height:height*1,}}>
        <ImageBackground  style={{ height:height*0.61,width:'100%',backgroundColor:'#f7ac42'}} resizeMode="contain" source={images.backimg}>
        <View style={styles.skipView}>
<TouchableOpacity onPress={()=>navigation.goBack()}   style={styles.skipbtn}>
<Image style={styles.skipimg} source={images.back}></Image>
</TouchableOpacity>
      </View>
          <View style={styles.logoView}>
          </View>
          <View style={styles.backView}>  
        
          </View>
          <View style={styles.startedView}>

<View style={styles.logoView1}>
<Text style={styles.enterLoc}>Name</Text>
<View style={styles.locationinput}>


<TextInput 
editable={false}
style={styles.locinput} 
placeholder='Your name'
value={name}
/>
</View>
<Text style={styles.enterLoc}>Email</Text>
<View style={styles.locationinput}>

<TextInput 
editable={false}
style={styles.locinput} 
placeholder='Email'
value={email}
/>
</View>
<Text style={styles.enterLoc}>Phone</Text>
<View style={styles.locationinput}>
<View style={{width:'20%',flexDirection:'row',borderRightWidth:0.5}}>
  <View style={{alignItems:'center',justifyContent:'center',paddingHorizontal:'5%',width:'40%'}} >
  <Image style={{height:25,width:25,resizeMode:'contain'}} source={images.country}></Image>

  </View>
<View style={{width:'60%', alignItems:'center',justifyContent:'center',paddingHorizontal:'5%'}}>
  <Text style={styles.locinput}>+1</Text>
</View>
</View>
<TextInput 
editable={false}
style={styles.locinput} 
placeholder='Phone number'/>
</View>

<View style={styles.bottomView} >
<TouchableOpacity onPress={()=>onLogout()} style={styles.bottomBtn}>
<Text style={styles.btnText}>Logout</Text>
<Image style={{height:20,width:20,resizeMode:'contain',marginHorizontal:10}} source={images.logout}></Image>

</TouchableOpacity>
          </View>
</View>
          </View>
        </ImageBackground>
 
          </View>
          </KeyboardAwareScrollView>
                 
    </View>
  )
}

export default Profile

