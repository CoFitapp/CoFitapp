import { NativeModules, PixelRatio, FlatList, StyleSheet, Text, View, useWindowDimensions, Image, Touchable, TouchableOpacity, TextInput, ImageBackground, Platform, Linking } from 'react-native'
import React, { useState } from 'react'
import styles from './style'
import images from '../../constants/images'
import colors from '../../constants/colors'
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { useRoute } from '@react-navigation/native'
import moment from 'moment'
import HTMLView from 'react-native-htmlview';
import MapView, { Marker, AnimatedRegion, Animated } from 'react-native-maps';
import { useEffect } from 'react'
import { useSelector } from 'react-redux'

const { StatusBarManager } = NativeModules;
const statusBarHeight = StatusBarManager.HEIGHT;
const fontScale = PixelRatio.getFontScale();
const fontSize = size => size / fontScale;
const apiKey = "AIzaSyBpVX6Xl4OEftECYrN-wauMw7dpUyl6GiI";

const EventDetail = ({ navigation }) => {
  const userLocation = useSelector(state=>state.user.location)
  const route = useRoute();
  const [event, setEvent] = useState(route.params.item)
  const { height, width } = useWindowDimensions();
  const [latitude, setLatitude] = useState(0)
  const [longitude, setLongitude] = useState(0)
  const [isMapVisible, setIsMapVisible] = useState(true)
  const [events, setEvents] = useState([
    {
      'image': images.event1,
      'distance': "8+",
      'time': "Tue, Sep 12 | 7:00pm",
      'name': "Fitness Challenge - Get Trophy by Courier",
      'location': "4550 Mueller bivid park, NJ"
    },
    {
      'image': images.event2,
      'distance': "12+",
      'time': "Tue, Sep 12 | 7:00pm",
      'name': "Fitness Challenge - Get Trophy by Courier",
      'location': "4550 Mueller bivid park, NJ"
    },
    {
      'image': images.event1,
      'distance': "8+",
      'time': "Tue, Sep 12 | 7:00pm",
      'name': "Fitness Challenge - Get Trophy by Courier",
      'location': "4550 Mueller bivid park, NJ"
    },
    {
      'image': images.event2,
      'distance': "12+",
      'time': "Tue, Sep 12 | 7:00pm",
      'name': "Fitness Challenge - Get Trophy by Courier",
      'location': "4550 Mueller bivid park, NJ"
    },
  ])

  useEffect(() => {
    getCoordinates();
  }, [])

  const getCoordinates = async () => {

    try {
      const response = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(event.location)}&key=${apiKey}`);
      const data = await response.json();

      if (data.results.length > 0) {
        const locationData = data.results[0].geometry.location;
        console.log('duy23y723y8y328', locationData);
        setLatitude(locationData.lat);
        setLongitude(locationData.lng);
        setIsMapVisible(true)
      } else {
        console.error(`No results found for the provided location: ${event.location}`);

      }
    } catch (error) {
      console.error(`Error fetching geocode data for location: ${event.location}`, error);
    }
  };

  const onPressViewMap=async()=>{
    // let origin = "Chandigarh,India"
    // let destination = "Ambala, India"
    const googleMapsUrl = `https://www.google.com/maps/dir/?api=1&origin=${userLocation}&destination=${event.location}`;
    Linking.openURL(googleMapsUrl)
  }

  return (
    <View style={styles.mainView}>
      <KeyboardAwareScrollView style={styles.keyboard}>
        <View style={styles.view1}>
          <View style={styles.bgImgView}>
            <ImageBackground style={styles.bgImg} source={images.groupbg}>
              <View style={styles.view2}>
                <View style={{}}>
                  <TouchableOpacity onPress={() => navigation.goBack()} style={styles.skipbtn}>
                    <Image style={styles.skipimg} source={images.back}></Image>
                  </TouchableOpacity>
                </View>
                <View style={styles.view0}>
                  <View style={styles.kmView}>
                    <Image source={images.car} style={styles.carIcon} />
                    <Text style={styles.kmText}>{event.distance}</Text>
                  </View>
                </View>

              </View>
            </ImageBackground>
          </View>



          <View style={styles.backView}>

          </View>
          <View style={styles.startedView}>

            {/* <Text style={styles.startedText}>Let's get started</Text> */}
            <Text style={styles.enterLoc}>{event.summary}</Text>
            <View style={styles.DayView}>
              <View style={styles.calBg}>
                <Image source={images.calendar} style={styles.calImg}></Image>
              </View>
              <View style={styles.dayTextView}>
                <Text style={styles.dayText}>{moment(event.start.dateTime).format('dddd, MMMM D, YYYY')}</Text>
                <Text style={styles.timeText}>{moment(event.start.dateTime).format('h:mm A')} - {moment(event.end.dateTime).format('h:mm A')}</Text>
                <Text style={styles.timeText}>Times are displayed in your time zone</Text>

              </View>
            </View>

            <View style={styles.locView}>
              <View style={styles.calBg}>
                <Image source={images.location1} style={styles.calImg}></Image>
              </View>
              <View style={styles.dayTextView}>
                <Text style={styles.dayText}>{event.location}</Text>
                {/* <Text style={styles.timeText}>4550 Mueller vivid park, NJ 16203</Text> */}

              </View>
            </View>
            <Text style={styles.eventText}>
              Event Details
            </Text>
            <View style={styles.eventDescription}>
              {/* <Text style={styles.eventDetailText}>{event.description}</Text> */}
              <HTMLView
                value={`<p>${event.description}</p>`}
                stylesheet={{
                  p: {
                    fontSize: 14,
                    fontFamily: "SFProText-Regular",
                    color: "#69707A"
                  },
                }}
              />
            </View>

            <View style={styles.shareWithFrndsView}></View>
            <Text style={styles.shareWithFrndsText}>
              Share With your friends
            </Text>
            <View style={styles.eventDescription}>
              <Text style={styles.enjoyText}>
                and enjoy a shared experience
              </Text>
            </View>
            <View style={styles.shareWithFrndsView}></View>

            <View>

            </View>
          </View>
          <View style={styles.view4}></View>

          <View style={styles.aboutView}>

            <View style={styles.aboutText}>
              <Text style={styles.shareWithFrndsText}>
                About event
              </Text>
              <View style={styles.eventDescription}>
                <Text style={styles.enjoyText}>
                  and enjoy a shared experience
                </Text>



              </View>
            </View>
            <View style={styles.readMoreBtn}>
              <TouchableOpacity style={styles.readMoreClick}>
                <Text style={styles.readMoreText}>READ MORE</Text>
              </TouchableOpacity>
            </View>
          </View>

          {
            isMapVisible &&
            <View style={styles.mapView}>
              <MapView
                zoomEnabled={true}
                minZoomLevel={1}
                style={styles.mapStyle}
                region={{
                  latitude: latitude,
                  longitude: longitude,
                  latitudeDelta: 0.0922,
                  longitudeDelta: 0.0421,
                }}

              >
                <Marker
                  // key={index}
                  image={images.location3}
                  coordinate={{ latitude: Number(latitude), longitude: Number(longitude) }}
                >
                </Marker>
              </MapView>


            </View>
          }
          <TouchableOpacity onPress={()=>onPressViewMap()} style={styles.viewOnMapView}>
            <Image source={images.group} style={styles.viewMapIcon} />
            <Text style={styles.viewOnMapText}>
              VIEW ON MAPS
            </Text>
          </TouchableOpacity>
          <View style={styles.shareWithFrndsView}></View>
          <Text style={styles.youMay}>
            You may love these too
          </Text>

          <FlatList
            data={events}
            scrollEnabled={false}
            renderItem={({ item, index }) => {
              return (
                <View style={styles.flatListView}>
                  <View style={styles.flatListView1}>
                    <View style={styles.flatListItem} >
                      <ImageBackground style={styles.flatListImg} resizeMode="stretch" source={images.event1}>
                        <View style={styles.kmbutton}>
                          <Image source={images.car} style={styles.carImg} />
                          <Text style={styles.kmText}>{item.distance} km</Text>
                        </View>
                      </ImageBackground>
                    </View>
                    <View style={styles.dateView}>
                      <Image source={images.time} style={styles.clockIcon} />
                      <Text style={styles.dateText}>{item.time}</Text>
                    </View>
                    <Text style={styles.summaryText}>{item.name}</Text>
                    <View style={styles.dateView}>
                      <Image source={images.location} style={styles.locIconB} />
                      <Text style={styles.locText}>{item.location}</Text>
                    </View>
                    <View style={styles.view3} />
                    <TouchableOpacity onPress={() => navigation.navigate("EventDetail")} style={styles.shareBtn}>
                      <Image source={images.share} style={styles.clockIcon} />
                      <Text style={styles.shareText}>Share event</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              )
            }}
          />

        </View>

      </KeyboardAwareScrollView>

    </View>
  )
}

export default EventDetail

